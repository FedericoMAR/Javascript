

max (2, 3);

function max(a, b){

    console.log(a, b)

    return (a > b)? a: b;
    

}