
const nani = ['pisolo', 'eolo', "gongolo", 'brontolo'];

nani.push('mammolo')

const nanoRimosso = nani.pop();

for (const nano of nani) {
    console.log(nano);
}
console.log(nani.length);
console.log(nanoRimosso);