
function fizzbuzz(n) {
    
    if (n != number) return NaN;

    
    

}
