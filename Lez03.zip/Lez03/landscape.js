
function isLandscape(width, heigth) {
    return (width > heigth)
}